package com.gentec.bstrack;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface UserBSTrack {
    @POST("Users/InsertDataUnAuth")
    Call<Object> InsertUserLocation(@Body Object object);
}
