package com.gentec.bstrack;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BSTrackService extends Service {

    private LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(@NonNull LocationResult locationResult) {
            super.onLocationResult(locationResult);
            if (locationResult != null && locationResult.getLastLocation() != null)
            {
                double latitude  = locationResult.getLastLocation().getLatitude();
                double longitude  = locationResult.getLastLocation().getLongitude();
                String deviceId =  getDeviceId(getApplicationContext());
                Log.d("Location_Update", latitude + ","+longitude);
                Map<String, Object> postparams = new HashMap<String, Object>();
                postparams.put("SPNAME", "CRM_DataEntryGeolocationSP");
                String version = getString(R.string.app_version);
                postparams.put("ReportQueryParameters", new Object[] { "@nType", "@nsType", "@GPFormId", "@UserId", "@Latitude", "@Longitude", "@DocumentNo", "@Event"});
                postparams.put("ReportQueryValue", new Object[] {  "1", "3", "36", deviceId, latitude, longitude, deviceId,  version});
                postparams.put("SPNAME", "CRM_DataEntryGeolocationSP");
//                JSONObject json=new JSONObject();
//                try {
//                    json.put("SPNAME", "CRM_DataEntryGeolocationSP");
//                    json.put("ReportQueryParameters", new JSONArray(new Object[] { "@nType", "@nsType", "@GPFormId", "@UserId", "@Latitude", "@Longitude", "@DocumentNo", "@Event"} ) );
//                    json.put("ReportQueryValue", new JSONArray(new Object[] { "1", "2", "36", deviceId, latitude, longitude, "", "BS Track: "+deviceId} ) );
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }

                UserBSTrack service = RetrofitInstance.getRetrofitInstance().create(UserBSTrack.class);
                Call<Object> call = service.InsertUserLocation(postparams);
                call.enqueue(new Callback<Object>() {
                    @Override
                    public void onResponse(Call<Object> call, Response<Object> response) {
                        Log.d("Location_Response", response.message());
                    }

                    @Override
                    public void onFailure(Call<Object> call, Throwable t) {
                        Log.d("Location_Response", "Something went wrong...Error message: " + t.getMessage());
                    }
                });


            }
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented.");
    }
    private void startBSTrack(){
        String channelId = "locatoin_notification_channel";
        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        Intent resultIntent = new Intent();
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), channelId);
        builder.setSmallIcon(R.mipmap.ic_launcher);
        builder.setContentTitle(getString(R.string.app_name));
        builder.setDefaults(NotificationCompat.DEFAULT_ALL);
        builder.setContentIntent(pendingIntent);
        builder.setAutoCancel(false);
        builder.setPriority(NotificationCompat.PRIORITY_MAX);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            if(notificationManager != null && notificationManager.getNotificationChannel(channelId) == null){
                NotificationChannel notificationChannel = new NotificationChannel(channelId,getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
                notificationChannel.setDescription("This channel is used by location service");
                notificationManager.createNotificationChannel(notificationChannel);

            }
        }
        //900000
//        long minutes = 60000;// 1 minutes
        long minutes = 300000;// 5 minutes

        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setInterval(minutes);
        locationRequest.setFastestInterval(minutes);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationServices.getFusedLocationProviderClient(this).requestLocationUpdates(locationRequest,locationCallback, Looper.getMainLooper());
        startForeground(Constants.LOCATION_SERVICE_ID, builder.build());
    }
    private void stopBSTrack(){
        LocationServices.getFusedLocationProviderClient(this).removeLocationUpdates(locationCallback);
        stopForeground(true);
        stopSelf();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(intent != null){
            String action = intent.getAction();
            if(action != null){
                if(action.equals(Constants.ACTION_START_LOCATION_SERVICE)){
                    startBSTrack();
                }else if(action.equals(Constants.ACTION_STOP_LOCATION_SERVICE)){
                    stopBSTrack();
                }
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }
    public static String getDeviceId(Context context) {

        String deviceId;

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            deviceId = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
        } else {
            final TelephonyManager mTelephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (mTelephony.getDeviceId() != null) {
                deviceId = mTelephony.getDeviceId();
            } else {
                deviceId = Settings.Secure.getString(
                        context.getContentResolver(),
                        Settings.Secure.ANDROID_ID);
            }
        }

        return deviceId;
    }
}
