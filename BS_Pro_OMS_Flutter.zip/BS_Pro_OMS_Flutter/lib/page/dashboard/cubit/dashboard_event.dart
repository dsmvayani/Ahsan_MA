
abstract class DashboardEvent {}

class GetDashboardData extends DashboardEvent{}

class DashboardSubmitted extends DashboardEvent{}