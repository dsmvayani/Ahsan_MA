
abstract class LedgerEvent {}


class GetLedgerReport extends LedgerEvent{}