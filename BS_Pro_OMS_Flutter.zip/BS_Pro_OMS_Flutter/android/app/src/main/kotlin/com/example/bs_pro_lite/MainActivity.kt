package com.gentec.BSProOMS

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
